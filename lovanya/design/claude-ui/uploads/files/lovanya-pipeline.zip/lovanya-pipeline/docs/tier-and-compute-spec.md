# Lovänya — Tier Structure & Compute Economics

*Spec section · self-hosted open-model pipeline (segmentation → VLM analysis → render)*

> **Architecture locked:** all open-weight models, self-hosted, all-free at launch. Analysis = Qwen2.5-VL (3B default, 7B fallback) for both perception and judgment. No closed-AI API at runtime. Sophistication is carried by an externalized styling framework, not model size. Structured one-shot inference only — not conversational. See `architecture-decisions.md`.

---

## 1. Tier Definitions

| Capability | Free | Premium ($3.50/mo) |
|---|---|---|
| Wardrobe size | 25 garments | Unlimited |
| Garment auto-fill (add item) | ✓ | ✓ |
| Outfit Check | 1× / day, cheap path | Unlimited, full path |
| Generated visual feedback | — | ✓ |
| Avatar (Style Twin) render | Preview only *(TBD)* | Full render *(TBD)* |
| Home feed / tips / Photocard view | ✓ | ✓ |
| Photocard export | ✓ | ✓ (priority / higher res) |

**Design intent:** give away the operations that cost ~nothing and build the daily habit (Home, limited Outfit Check, wardrobe auto-fill); gate the GPU-heavy, aspirational operations (unlimited checks, generated feedback, avatar).

---

## 2. Pipeline Cost Basis

Self-hosted open models on rented serverless GPU (scale-to-zero), pay-per-second.

| Operation | Models invoked | Approx. cost |
|---|---|---|
| Garment add (auto-fill) | GroundingDINO + SAM2 + Qwen2.5-VL | ~$0.005 |
| Outfit Check — cheap path | Segmentation + rule-based match scoring | ~$0.001 |
| Outfit Check — full path | + VLM reasoning + SDXL/Flux visual | ~$0.005 |
| Avatar render *(TBD)* | Three.js + image model | highest; premium-only |

*Per-inference figures assume RTX 4090-class serverless at ~$0.69/hr; cold-start overhead handled by batching free-tier jobs.*

---

## 3. Compute Budget per Tier

### Free user — monthly cost
| Item | Volume | Cost |
|---|---|---|
| Wardrobe auto-fill | 25 items (one-time, amortized) | ~$0.01–0.02 |
| Outfit Check (cheap path) | ~30/mo (1/day) | ~$0.03 |
| Storage (25 images + JSON) | — | <$0.01 |
| **Total** | | **~$0.05/mo** |

> If free Outfit Check used the *full* path instead of cheap path, free cost rises to ~$0.11/mo. **Cheap-path-only for free is the key lever** — it keeps the model healthy even at low conversion.

### Premium user — monthly cost
| Item | Volume (generous) | Cost |
|---|---|---|
| Wardrobe auto-fill | trickle after onboarding | ~$0.10 |
| Outfit Check (full path) | daily + extras | ~$0.25 |
| Storage | unlimited wardrobe | ~$0.05 |
| **Total** | | **~$0.40/mo** |

---

## 4. Unit Economics

| Line | Premium |
|---|---|
| Revenue | $3.50 |
| App store fee (15% small-business) | –$0.53 |
| Net revenue | $2.97 |
| Compute + storage | –$0.40 |
| **Margin per premium user** | **~$2.57** |

### Break-even vs. free-tier load
Free user cost = **$0.05/mo** (cheap-path free tier).

| Conversion | Free users per premium | Free load cost | Covered by 1 premium margin? |
|---|---|---|---|
| 2% | ~50 | $2.50 | ≈ break-even |
| 3% | ~32 | $1.60 | ✓ profitable |
| 5% | ~19 | $0.95 | ✓ comfortable |

**Conclusion:** with the cheap-path free tier, the model is viable at industry-standard conversion (≥2–3%). The 1×/day check cap and 25-garment cap together hold free-tier cost near $0.05/user.

---

## 5. Phased Rollout & Cost Control (engineering)

The free tier deliberately runs as a **loss leader** in early phases. This is safe because absolute downside is bounded and small — even an all-free base of 1,000 users at full-path checks with no batching is ~$110/mo total. Batching and the cheap-path switch are introduced *only* when user density makes them work without hurting UX (a batch window with one user in it is just a timeout the user waits through).

| Phase | Trigger | Worker strategy | Free path | Posture |
|---|---|---|---|---|
| **Launch** | 0 → low users | Pure flex, scale-to-zero, accept cold-start latency | Full path OK | Deliberate loss leader |
| **Growth** | Batch window fills quickly (enough concurrent free jobs) | Introduce free-tier batching | Switch free → cheap path | Approaching break-even |
| **Scale** | ≥ ~25% monthly GPU utilization | Add warm worker | Cheap path locked | Profitable |

**Standing rules across all phases:**

1. **Scale-to-zero always on** — idle users cost nothing between sessions.
2. **Spend kill-switch / alert** — solo-operator safeguard. Set a spend alert (e.g. notify at $150/mo, review hard cap at $300) *below* RunPod's default ceiling. The only real risk in loss-leading is an unmonitored runaway: a looping inference bug or an abuse case scripting bulk uploads. Normal usage is not the threat; an unwatched 3am bug is.
3. **Front-loaded cost awareness** — onboarding bulk upload is the single largest per-user compute event; meter and rate-limit it (defends against the abuse case above).
4. **Cheap-path free check is the long-term lever** — not enforced at launch, but the switch that makes the model healthy at ≥2–3% conversion. Flip it when density allows batching, not before.

---

## 6. Conversion Levers (product)

- **25-item wall = primary conversion moment.** The "Wardrobe full → go unlimited" prompt lands on the most engaged users. Frame as invitation, not paywall.
- **Daily check limit** creates the habit, then the friction that motivates upgrade.
- **Avatar as premium prize** *(TBD)* — the most compute-heavy feature doubles as the strongest upgrade anchor once built.

---

## 7. Open Items

**Locked decisions:**
- ✓ Premium price: **$3.50/mo** (comfortable charging point; revisit only if conversion data demands).
- ✓ App stores: **Apple App Store + Google Play**, small-business fee tier (15%) at launch.
- ✓ Avatar: **postponed** to a future release; not in launch scope.
- ✓ Free-tier strategy: **launch full-path as loss leader**, flip to cheap-path + batching at the Growth trigger (§5).

**Still open:**
- [ ] Set concrete spend-alert thresholds in RunPod before launch (proposed: notify $150, review $300).
- [ ] Define the onboarding upload rate-limit (items/min) to cap the abuse vector.
- [ ] Determine the exact "batch window fills quickly" metric that triggers the Growth phase (e.g. ≥ N free jobs per 60s window).
- [ ] Finalize Avatar render cost model when that feature is revived (future).
